
> Sauf mention contraire, tous les pouvoirs ne sont utilisables qu'une fois.

### **Agile**
 Peut esquiver n'importe quel effet.
### **Bomberman**
 Lorsqu'un autre joueur pose une carte nombre sur la même carte nombre, il pioche une carte *(pouvoir permanent)*.
### **Chimiste fou**
 Lorsqu'un joueur fait Uno, il doit gagner un Chi-Fu-Mi contre le chimiste fou. S'il perd, il pioche deux cartes *(pouvoir permanent)*.
### **Dalton**
 Lorsque le joueur doit piocher, il regarde les 4 premières cartes, en choisit une et jette les autres *(pouvoir permanent)*.
### **Fossoyeur**
 Peut échanger les cartes de sa main contre autant de cartes du cimetière.
### **Musclé**
 Peut doubler la valeur d'un effet *(activale deux fois)*.
### **Promoteur**
 Peut transformer une carte nombre en carte "+nombre".
### **Roi**
 Peut interrompre le cours de la partie pour jouer une carte.
### **Shotgun**
 Peut jouer deux cartes à la suite.
### **Sonic**
 Devient le centre de l'attention et joue entre les tours *(pouvoir désactivable)*.
### **Switcher**
 Peut échanger sa main avec quelqu'un.
### **Tricheur**
 Peut défausser une carte de sa main.
### **Voyante**
 Peut forcer quelqu'un à révéler son jeu.
