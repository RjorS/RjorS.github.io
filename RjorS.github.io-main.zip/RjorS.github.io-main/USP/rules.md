### Jeu de cartes

- **7** = passe 1 tour.
- **V** = passe 2 tours.
- **10** = +1 carte.
- **A** = +2 cartes.
- **8** = Joker.

### Jeu de UNO

- Les **+2** et les **+4** peuvent se cumuler.
- Le **+2** ne passe pas le tour.
- Le **+4** passe aussi le tour.
  
